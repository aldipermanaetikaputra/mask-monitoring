# Using Camera2 API in Background
This sample shows how to use Camera2 API from a Service.

The Android app is showing 2 ways of using the camera
1. Camera preview is displayed over all other apps, even when your Activity is not foreground
2. There is no preview shown, but the camera still delivers frames that can be processed in the background even when your Activity is not foreground

This Android Studio project is related to my blogpost about Camera2 API
[sisik.eu/blog/android/media/camera2-from-service](https://sisik.eu/blog/android/media/camera2-from-service)